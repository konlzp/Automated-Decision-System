'''
Created on Dec 21, 2015

@author: konlzp
'''
import random
import itertools
import time

# define globals for cards
SUITS = ('C', 'S', 'H', 'D')
RANKS = ('A', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K')
VALUES = {'A':14, '2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13}

tokens = ['Adele', 'Britney', 'Clair', 'Denis', 'Eve', 'Flower', 'Gwen', 'Hector', 'Ivy', 'Jack', 'Kyle', 'Loki']


# define card class
class Card:
    def __init__(self, suit, rank):
        if (suit in SUITS) and (rank in RANKS):
            self.suit = suit
            self.rank = VALUES[rank]
            self.strRank = rank
        else:
            self.suit = None
            self.rank = None
            print "Invalid card: ", suit, rank

    def __str__(self):
        return self.suit + self.strRank

    def get_suit(self):
        return self.suit

    def get_rank(self):
        return self.rank

class Player:
    def __init__(self, asset, token):
        self.token = token
        self.cards = []
        self.bid = 0
        self.asset = asset
        self.status = 1
        self.rank = Rank('idle', rank1 = -1)

    def fold(self):
        self.status = 0

    def makeBid(self, bid):
        if self.asset > bid - self.bid :
            self.asset -= bid - self.bid
            self.bid = bid
            return 1
        else:
            return 0

    def clear(self):
        self.cards = []
        self.bid = 0
        self.rank = Rank('idle', rank1 = -1)

    def collectBid(self, reward):
        self.asset += reward

    def __str__(self):
        return "Player " + self.token + " current asset: " + str(self.asset)

    def cardInfo(self):
        ret = "Current holding: "
        for card in self.cards:
            ret += str(card) + " "
        return ret

    def add_card(self, card):
        self.cards.append(card)
        # add a card object to a hand

    def get_value(self):
        value = 0
        aces = False
        for c in self.cards:
            rank = c.get_rank()
            v = VALUES[rank]
            if rank == 'A': aces = True
            value += v
        if aces and value < 12: value += 10
        return value
    
    def privateScore(self):
        if self.cards[0].rank == self.cards[1].rank:
            return self.cards[0].rank * 14
        else:
            return self.cards[0].rank + self.cards[1].rank

# define deck class
class Deck:
    def __init__(self):
        self.deck = []
        self.bid = 0
        self.highBid = 0
        for s in SUITS:
            for r in RANKS:
                self.deck.append(Card(s, r))
        # create a Deck object

    def __str__(self):
        ans = "The deck: "
        for c in self.deck:
            ans += str(c) + " "
        return ans
        # return a string representing the deck

    def getBid(self):
        return self.bid

    def addBid(self, bid):
        self.bid += bid

    def getHighBid(self):
        return self.highBid

    def shuffle(self):
        random.shuffle(self.deck)
        # shuffle the deck

    def deal_card(self):
        return self.deck.pop()


class Public:
    def __init__(self):
        self.cards = []

    def __str__(self):
        ret = ""
        for card in self.cards:
            ret += str(card) + " "
        return ret

class Rank:
    def __init__(self, name, rank1 = None, rank2 = None, rank3 = None, rank4 = None, rank5 = None, rank6 = None):
        self.rank = [rank1, rank2, rank3, rank4, rank5, rank6]
        self.name = name

    def __gt__(self, other):
        for count in range(0, len(self.rank)):
            if self.rank[count] < other.rank[count]:
                return False
            elif self.rank[count] > other.rank[count]:
                return True

        return False

    def __eq__(self, other):
        for count in range(0, len(self.rank)):
            if self.rank[count] != other.rank[count]:
                return False
        return True

    def score(self):
        result = 0
        for rank in self.rank:
            result *= 14
            if rank is not None:
                result += rank
            else:
                result += 0
        return result
    
    def __str__(self):
        ret = ""
        ret += self.name + " "
        for rank in self.rank:
            if rank is not None:
                ret += str(rank) + " "
        return ret

def isStraight(cards) :
    # Determine if the sorted cards are straight
    prev = None
    for card in cards:
        if prev is None:
            prev = card
        else:
            if card.rank != prev.rank + 1:
                return False

    return True

def isFlush(suits):
    if len(suits.keys()) == 1:
        return True
    return False

def countRank(ranks, target) :
    count = 0
    result = []
    for key in ranks:
        if ranks[key] == target:
            count += 1
            result.append(key)
    return (result, count)

def calcPlayerScore(cards):
    # Given five cards, calculate its score based on the Texas Hold'em rule
    rankDict = {}
    suitDict = {}
    cards.sort(cmp = None, key = lambda x: x.rank, reverse = False)
    # Sort the cards by their ranks
    for card in cards:
        if suitDict.get(card.suit) is not None:
            suitDict[card.suit] += 1
        else:
            suitDict[card.suit] = 1
        if rankDict.get(card.rank) is not None:
            rankDict[card.rank] += 1
        else:
            rankDict[card.rank] = 1

    straightFlag = isStraight(cards)
    royalFlag = (cards[4].rank == 14)
    flushFlag = isFlush(suitDict)
    (fourResult, fourFlag) = countRank(rankDict, 4)
    (threeResult, threeFlag) = countRank(rankDict, 3)
    (pairResult, pairFlag) = countRank(rankDict, 2)

    if flushFlag and royalFlag and straightFlag:
        return Rank("Royal Flush", rank1 = 9)
    elif straightFlag and flushFlag:
        return Rank("Straight Flush", rank1 = 8, rank2 = cards[4].rank)
    elif fourFlag:
        for key in rankDict:
            if key != fourResult[0]:
                return Rank("Four of a Kind", rank1 = 7, rank2 = fourResult[0], rank3 = key)
    elif threeFlag and pairFlag:
        return Rank("Full House", rank1 = 6, rank2 = threeResult[0], rank3 = pairResult[0])
    elif flushFlag:
        return Rank("Flush", rank1 = 5, rank2 = cards[4].rank, rank3 = cards[3].rank, rank4 = cards[2].rank, rank5 = cards[1].rank, rank6 = cards[0].rank)
    elif straightFlag:
        return Rank("Straight", rank1 = 4, rank2 = cards[4].rank)
    elif threeFlag:
        otherThree = []
        for card in cards:
            if card.rank != threeResult[0]:
                otherThree.append(card.rank)

        return Rank("Three of a Kind", rank1 = 3, rank2 = threeResult[0], rank3 = otherThree[1], rank4 = otherThree[0])
    elif pairFlag and len(pairResult) == 2:
        pairResult.sort()
        for key in rankDict:
            if key not in pairResult:
                return Rank("Two Pairs", rank1 = 2, rank2 = pairResult[1], rank3 = pairResult[0], rank4 = key)
    elif pairFlag:
        otherTwo = []
        for card in cards:
            if card.rank != pairResult[0]:
                otherTwo.append(card.rank)

        return Rank("One Pair", rank1 = 1, rank2 = pairResult[0], rank3 = otherTwo[2], rank4 = otherTwo[1], rank5 = otherTwo[0])
    else:
        return Rank("High Card", rank1 = 0, rank2 = cards[4].rank, rank3 = cards[3].rank, rank4 = cards[2].rank, rank5 = cards[1].rank, rank6 = cards[0].rank)

def countOnes(players, actionHistory):
    nominator = 0
    denominator = 0
    for i, player in enumerate(players):
        if player.status == 1 and actionHistory[i] == 1:
            nominator += 1
            denominator += 1
        elif player.status == 1:
            denominator += 1
    return float(nominator) / denominator

def calcProb(player, players, deck, public, actionHistory):
    scores = []
    scores.append(player.rank.score() / float(2 * (14 ** 5)))
    scores.append(player.privateScore() / float(7 * 14))
    scores.append(1 - countOnes(players, actionHistory))
    scores.append(1 - (deck.highBid - player.bid) / float(player.asset))
    
    weights = [3, 2, 1, 1]
    finalScore = 0
    for i, score in enumerate(scores):
        finalScore += score * weights[i]
    finalScore /= sum(weights)
    #print(finalScore)
    
    return finalScore
    
def calcRank(player, public):
    allCards = player.cards + public.cards
    maxRank = Rank("idle", rank1 = -1)

    for cards in itertools.permutations(allCards, 5):
        tempRank = calcPlayerScore(list(cards))
        if tempRank > maxRank:
            maxRank = tempRank

    return maxRank

def printPlayers(players):
    print("Players info:")
    for player in players:
        print(player)
        
def equalBid(players):
    curBid = None
    for player in players:
        if player.status == 1:
            if curBid is None:
                curBid = player.bid
            elif curBid != player.bid:
                return False
    return True
                
def noOneElse(player, players):
    for other in players:
        if other.token != player.token:
            if other.status == 1:
                return False
    return True

def gamePlay(numPlayer):
    players = []
    random.shuffle(tokens)
    for i in range(0, numPlayer):
        players.append(Player(1000, tokens[i]))
    bigBlind = 0
    smallBlind = 1
    userID = random.randint(0, numPlayer - 1)
    actionHistory = [0 for i in range(0, len(players))]

    while len(players) > 1:
        deck = Deck()
        deck.shuffle()
        public = Public()
        for i in range(0, len(players)):
            players[i].cards.append(deck.deal_card())
            players[i].cards.append(deck.deal_card())
            players[i].status = 1

        for i in range(0, 3):
            public.cards.append(deck.deal_card())

        players[bigBlind].makeBid(10)
        players[smallBlind].makeBid(5)
        deck.addBid(10)
        deck.addBid(5)
        deck.highBid = 10

        count = 0
        remaining = players
        while count < 3 and len(remaining) > 1:
            flag = 0
            while (not equalBid(remaining)) or (flag == 0):
                for i in range(0, len(players)):
                    ind = (i + bigBlind + 2) % len(players)
                    player = players[ind]
                    if player.status == 1:
                        action = ""
                        player.rank = calcRank(player, public)
                        if ind == userID:
                            print(public)
                            print(player.cardInfo())
                            
                            nextMove = input("Next move? (fold = 1, call = 2, raise = 3, info = 4)")
                            while nextMove not in range(1, 5):
                                print(nextMove + 'INVALID COMMAND')
                                nextMove = input("Next move? (fold = 1, call = 2, raise = 3, info = 4)")
                            
                            while nextMove == 4:
                                printPlayers(players)
                                nextMove = input("Next move? (fold = 1, call = 2, raise = 3, info = 4)")
                                while nextMove not in range(1, 5):
                                    print(nextMove + 'INVALID COMMAND')
                                    nextMove = input("Next move? (fold = 1, call = 2, raise = 3, info = 4)")
    
                            if nextMove == 1:
                                myBid = 0
                            elif nextMove == 2:
                                action = 'call'
                                myBid = min(player.asset, deck.highBid)
                            elif nextMove == 3:
                                action = 'raise'
                                raisedBid = min(deck.highBid + 0.1 * player.asset, 2 * deck.highBid)
                                myBid = min(player.asset, raisedBid)
                                
                        else:
                            #print(player.cardInfo())
                            if noOneElse(player, players):
                                print("noOneElse")
                                myBid = min(player.asset, deck.highBid)
                                action = 'call'
                            else:
                                winProb = calcProb(player, players, deck, public, actionHistory)
                                if winProb >= 0.8:
                                    raisedBid = min(deck.highBid + 0.1 * player.asset, 2 * deck.highBid)
                                    myBid = min(player.asset, raisedBid)
                                    action = 'raise'
                                elif winProb >= 0.6:
                                    action = 'call'
                                    myBid = min(player.asset, deck.highBid)
                                else:
                                    myBid = 0
                        if myBid == 0:
                            action = 'fold'
                            player.fold()
                            actionHistory[ind] = 0
                        else:
                            actionHistory[ind] = 1
                            deck.addBid(myBid - player.bid)
                            player.makeBid(myBid)
                            deck.highBid = max(deck.highBid, myBid)
    
                        print("Player " + player.token + " " + action + ". Current bid: " + str(player.bid))
                        print("")
                        time.sleep(0.1)
                        flag = 1
            remaining = filter(lambda x: x.status == 1, players)
            public.cards.append(deck.deal_card())
            count += 1


        # Showdown
        maxIndex = -1
        maxRank = Rank('idle', rank1 = -1)
        for i, player in enumerate(players):
            if player.status == 1:
                if player.rank > maxRank:
                    maxIndex = i
                    maxRank = player.rank
                player.fold()
        print("Player "+ players[maxIndex].token + " wins, with a " + maxRank.name + ". Cards: " + players[maxIndex].cardInfo())
        players[maxIndex].collectBid(deck.bid)
        
        for player in players:
            player.clear()
            
        printPlayers(players)
        
        players = filter(lambda x: x.asset > 0, players)
        
        bigBlind = (bigBlind + 1) % len(players)
        smallBlind = (smallBlind + 1) % len(players)

gamePlay(5)